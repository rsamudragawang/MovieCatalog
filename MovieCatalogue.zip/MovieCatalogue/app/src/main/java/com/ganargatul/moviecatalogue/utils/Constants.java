package com.ganargatul.moviecatalogue.utils;

public class Constants {
    public static final String IS_DAILY_REMINDER="IS_DAILY_REMINDER";
    public static final String IS_RELEASE_REMINDER="IS_RELEASE_REMINDER";

}
