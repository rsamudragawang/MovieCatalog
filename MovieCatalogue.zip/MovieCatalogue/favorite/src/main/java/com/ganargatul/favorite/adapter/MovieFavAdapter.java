package com.ganargatul.favorite.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ganargatul.favorite.R;
import com.ganargatul.favorite.model.MovieTvFavItems;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class MovieFavAdapter extends RecyclerView.Adapter<MovieFavAdapter.MovieTvFavAdapterViewHolder> {
    Context context;
    Cursor cursor;
    OnItemClickListener mListener;
    public interface OnItemClickListener{
        void onItemClick(int position);
    }
    public void SetOnItemClickListener(OnItemClickListener mListener){
        this.mListener = mListener;
    }
    public MovieFavAdapter(Context context) {
        this.context = context;
    }
    public void setmMovieTvItems(Cursor movieTvFavItems) {

        this.cursor = movieTvFavItems;
    }
    @NonNull
    @Override
    public MovieTvFavAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.movietvfav_items,parent,false);

        return new MovieTvFavAdapterViewHolder(v);
    }
    private MovieTvFavItems getItems(int position){
        if (!cursor.moveToPosition(position)){
            throw new IllegalStateException("Invalid");
        }
        return new MovieTvFavItems(cursor);
    }
    @Override
    public void onBindViewHolder(@NonNull MovieTvFavAdapterViewHolder holder, int position) {
        MovieTvFavItems movieTvFavItems = getItems(position);
        Picasso.with(context).load("https://image.tmdb.org/t/p/w500"+movieTvFavItems.getPhoto()).into(holder.mCircleImageView);
        holder.mTitle.setText(movieTvFavItems.getTitle());
    }

    @Override
    public int getItemCount() {
        if (cursor==null)return 0;
        return cursor.getCount();
    }

    public class MovieTvFavAdapterViewHolder extends RecyclerView.ViewHolder {
        TextView mTitle;
        CircleImageView mCircleImageView;
        public MovieTvFavAdapterViewHolder(@NonNull View itemView) {
            super(itemView);
            mCircleImageView = itemView.findViewById(R.id.image_items);
            mTitle = itemView.findViewById(R.id.title_items);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mListener !=null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            mListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
